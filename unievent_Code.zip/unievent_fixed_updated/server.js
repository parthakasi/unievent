// ========================== server.js ==========================
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ========================== Middleware ==========================
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ========================== Static Frontend ==========================
app.use(express.static(path.join(__dirname, 'public')));

// ========================== Database + Routes ==========================
const db = require('./src/models/db'); // ✅ correct path
const eventRoutes = require('./src/routes/events'); // ✅ correct path
const userRoutes = require('./src/routes/users');   // ✅ correct path

app.use('/api/events', eventRoutes);
app.use('/api/users', userRoutes);

// ========================== Test API ==========================
app.get('/api', (req, res) => {
  res.send('✅ UniEvent API is running successfully');
});

// ========================== Catch-All Frontend Route ==========================
// 🧠 Express 5 fix — use RegExp instead of '*'
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ========================== Start Server ==========================
app.listen(PORT, () => {
  console.log(`🚀 UniEvent Server is running on http://localhost:${PORT}`);
});
