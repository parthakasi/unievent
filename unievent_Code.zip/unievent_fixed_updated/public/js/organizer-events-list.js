document.addEventListener("DOMContentLoaded", async () => {
  const organizerId = sessionStorage.getItem("organizerUserId");
  const organizerDept = sessionStorage.getItem("organizerDeptName");

  if (!organizerId) {
    window.location.href = "organizer-login-form.html";
    return;
  }

  const deptSpan = document.getElementById("organizer-dept-name");
  if (deptSpan) deptSpan.textContent = organizerDept || "Your Department";

  const tbody = document.getElementById("events-table-body");

  // Fetch and render all events for the organizer
  async function fetchEvents() {
    tbody.innerHTML = `
      <tr><td colspan="6" class="loading-row">
        <i class="fas fa-spinner fa-spin"></i> Loading events...
      </td></tr>`;

    try {
      const res = await fetch(`/api/events/department/${encodeURIComponent(organizerDept)}/${organizerId}`);
      const events = await res.json();

      if (!res.ok || events.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-row">No events found.</td></tr>`;
        return;
      }

      tbody.innerHTML = "";

      events.forEach((e) => {
        const status = e.registration_closed === 1 ? "Closed" : "Open";
        const dateTime = `${e.date}<br><small>${e.start_time} - ${e.end_time}</small>`;
        const statusClass = e.registration_closed === 1 ? "closed" : "open";

        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${e.title}</td>
          <td>${dateTime}</td>
          <td>${e.venue}</td>
          <td>${e.totalComps}</td>
          <td>${e.totalRegistrations}</td>
          <td>
            <span class="status-badge ${statusClass}">${status}</span><br>
            <button class="close-btn" data-id="${e.id}" ${e.registration_closed === 1 ? "disabled" : ""}>
              <i class="fas fa-lock"></i> Close
            </button>
            <button class="delete-btn" data-id="${e.id}">
              <i class="fas fa-trash"></i> Delete
            </button>
            <button class="view-btn" data-id="${e.id}">
              <i class="fas fa-users"></i> View
            </button>
          </td>
        `;

        tbody.appendChild(tr);
      });

      attachButtonListeners();
    } catch (err) {
      console.error("Error fetching events:", err);
      tbody.innerHTML = `<tr><td colspan="6" class="error-row">Error loading events.</td></tr>`;
    }
  }

  function attachButtonListeners() {
    document.querySelectorAll(".close-btn").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        const eventId = btn.dataset.id;
        if (btn.disabled) return;
        const confirmClose = confirm("Are you sure you want to close registration for this event?");
        if (confirmClose) await closeEvent(eventId);
      });
    });

    document.querySelectorAll(".delete-btn").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        const eventId = btn.dataset.id;
        const confirmDel = confirm("⚠️ Are you sure you want to permanently delete this event?");
        if (confirmDel) await deleteEvent(eventId);
      });
    });

    document.querySelectorAll(".view-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const eventId = btn.dataset.id;
        loadRegistrations(eventId);
      });
    });
  }

  // Close registration
  async function closeEvent(eventId) {
    try {
      const res = await fetch(`/api/events/close/${eventId}`, { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      showAlert(data.message, "success");
      fetchEvents();
    } else {
      showAlert(data.error || "Failed to close registration.", "error");
    }
  } catch (err) {
    console.error(err);
    showAlert("Network error while closing registration.", "error");
  }
}

// Delete event
async function deleteEvent(eventId) {
  try {
    const res = await fetch(`/api/events/delete/${eventId}`, { method: "DELETE" });
    const data = await res.json();

    if (res.ok) {
      showAlert(data.message, "success");
      fetchEvents();
    } else {
      showAlert(data.error || "Failed to delete event.", "error");
    }
  } catch (err) {
    console.error(err);
    showAlert("Network error while deleting event.", "error");
  }
}

// 🧾 Load registered students with CSV download
async function loadRegistrations(eventId) {
  try {
    const res = await fetch(`/api/events/registrations/${eventId}`);
    const regs = await res.json();

    const modal = document.createElement("div");
    modal.className = "registrations-modal";
    modal.innerHTML = `
      <div class="modal-content">
        <h3><i class="fas fa-users"></i> Registered Students</h3>
        <button class="modal-close-btn">&times;</button>
        ${
          regs.length === 0
            ? `<p>No students registered yet.</p>`
            : `
            <button class="csv-btn"><i class="fas fa-file-download"></i> Download CSV</button>
            <table class="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Reg No</th>
                  <th>Department</th>
                  <th>Competition</th>
                  <th>Fee</th>
                </tr>
              </thead>
              <tbody>
                ${regs
                  .map(
                    (r) => `
                    <tr>
                      <td>${r.student_name}</td>
                      <td>${r.regno || "-"}</td>
                      <td>${r.student_dept}</td>
                      <td>${r.comp_name}</td>
                      <td>${r.registration_fee || "Free"}</td>
                    </tr>`
                  )
                  .join("")}
              </tbody>
            </table>`
        }
      </div>
    `;
    document.body.appendChild(modal);

    // CSV download handler
    const csvBtn = modal.querySelector(".csv-btn");
    if (csvBtn && regs.length > 0) {
      csvBtn.addEventListener("click", () => downloadCSV(regs, "registrations.csv"));
    }

    const closeBtn = modal.querySelector(".modal-close-btn");
    closeBtn.addEventListener("click", () => modal.remove());
    modal.addEventListener("click", (e) => {
      if (e.target === modal) modal.remove();
    });
  } catch (err) {
    console.error(err);
    showAlert("Failed to load registrations.", "error");
  }
}

// 📥 Convert registrations to CSV and trigger download
function downloadCSV(data, filename) {
  const csvRows = [];
  const headers = Object.keys(data[0]);
  csvRows.push(headers.join(","));

  for (const row of data) {
    const values = headers.map((h) => `"${(row[h] || "").toString().replace(/"/g, '""')}"`);
    csvRows.push(values.join(","));
  }

  const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
}

fetchEvents();
});
