
document.addEventListener('DOMContentLoaded', function(){
  const dateEl = document.getElementById('date');
  const startEl = document.getElementById('start_time');
  const endEl = document.getElementById('end_time');
  const venueEl = document.getElementById('venue');
  if (!dateEl || !startEl || !endEl || !venueEl) return;

  const check = async () => {
    const date = dateEl.value; const start_time = startEl.value; const end_time = endEl.value;
    if (!date || !start_time || !end_time) return;
    // For each option, check conflict
    for (let i=0;i<venueEl.options.length;i++){
      const opt = venueEl.options[i];
      if (!opt.value) continue;
      const resp = await fetch('/api/events/check-conflict', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({date, venue: opt.value, start_time, end_time})});
      const j = await resp.json();
      if (j.isConflict) {
        opt.disabled = true;
        opt.text = opt.value + " (booked)";
      } else {
        opt.disabled = false;
        opt.text = opt.value;
      }
    }
  };

  dateEl.addEventListener('change', check);
  startEl.addEventListener('change', check);
  endEl.addEventListener('change', check);
});
