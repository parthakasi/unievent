document.addEventListener('DOMContentLoaded', () => {
  // ✅ Verify correct role and authentication
  const role = sessionStorage.getItem('userRole');
  const organizerId = sessionStorage.getItem('organizerUserId');
  const organizerName = sessionStorage.getItem('organizerUserName') || "Organizer";
  const departmentName = sessionStorage.getItem('organizerDeptName') || "Department";

  // 🚨 Redirect if not logged in as organizer
  if (role !== 'organizer' || !organizerId) {
    sessionStorage.clear();
    window.location.href = 'organizer-login-form.html';
    return;
  }

  // ✅ Display personalized welcome
  const welcomeMessage = document.getElementById('welcome-message');
  if (welcomeMessage) {
    welcomeMessage.textContent = `Hello, ${organizerName} (${departmentName})`;
  }

  // ✅ Fetch dashboard summary
  const fetchOrganizerMetrics = async (department) => {
    try {
      const response = await fetch(`/api/events/summary/${encodeURIComponent(department)}`);
      const data = await response.json();

      if (response.ok) {
        document.getElementById('total-active-events').textContent = data.totalActiveEvents || 0;
        document.getElementById('events-pending').textContent = data.totalPending || 0;
        document.getElementById('total-registrations').textContent = data.totalRegistrations || 0;
      } else {
        console.error('Failed to fetch organizer summary:', data.error);
        document.getElementById('total-active-events').textContent = 'N/A';
      }
    } catch (error) {
      console.error('Network error fetching organizer metrics:', error);
      document.getElementById('total-active-events').textContent = 'Error';
    }
  };

  if (departmentName) fetchOrganizerMetrics(departmentName);

  // ✅ Logout (clear only organizer session)
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      sessionStorage.removeItem('organizerUserId');
      sessionStorage.removeItem('organizerUserName');
      sessionStorage.removeItem('organizerDeptName');
      sessionStorage.removeItem('userRole'); // 🔥 Important cleanup

      // 🚫 Also clear any student session (safety)
      sessionStorage.removeItem('studentUserId');
      sessionStorage.removeItem('studentUserName');
      sessionStorage.removeItem('studentDeptName');
      sessionStorage.removeItem('studentUserYear');

      showAlert("You have been successfully logged out.", 'info');
      setTimeout(() => {
        window.location.href = 'index.html';
      }, 1000);
    });
  }
});


// ==================== PAYMENT MANAGEMENT ====================

// Load payments for an event and render them dynamically
async function loadPaymentsForEvent(eventId, container) {
  try {
    const res = await fetch(`/api/payments/events/${eventId}/payments`);
    const data = await res.json();

    container.innerHTML = '';

    if (!data.payments || data.payments.length === 0) {
      container.innerHTML = '<p>No payment proofs uploaded yet.</p>';
      return;
    }

    data.payments.forEach((p) => {
      const div = document.createElement('div');
      div.className = 'panel';
      div.innerHTML = `
        <strong>${p.user_name || ('User ' + p.user_id)}</strong> - ${p.status} <br>
        Uploaded: ${p.uploaded_at || ''} <br>
        <a href="${p.proof_path}" target="_blank">View Proof</a>
        <button data-payment="${p.id}" class="verify-btn">Mark Paid</button>
        <button data-payment="${p.id}" class="reject-btn">Reject</button>
      `;
      container.appendChild(div);
    });

    // ✅ Attach event listeners for buttons
    container.querySelectorAll('.verify-btn').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.dataset.payment;
        await fetch(`/api/payments/payments/${id}/verify`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'paid' })
        });
        loadPaymentsForEvent(eventId, container);
      });
    });

    container.querySelectorAll('.reject-btn').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.dataset.payment;
        await fetch(`/api/payments/payments/${id}/verify`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'rejected' })
        });
        loadPaymentsForEvent(eventId, container);
      });
    });
  } catch (err) {
    console.error(err);
    container.innerHTML = 'Failed to load payments.';
  }
}

// ==================== AUTO-LOAD PAYMENT PANELS ====================
document.addEventListener('DOMContentLoaded', function () {
  const organizerEventsContainer = document.getElementById('organizer-events-container');
  if (!organizerEventsContainer) return;

  const observer = new MutationObserver(() => {
    document.querySelectorAll('.event-item').forEach((el) => {
      if (el.dataset.paymentsAttached) return;
      const eventId = el.dataset.eventId;
      const paymentsDiv = document.createElement('div');
      paymentsDiv.className = 'payments-list panel';
      paymentsDiv.innerHTML = '<h4>Payment Proofs</h4><div class="payments-inner"></div>';
      el.appendChild(paymentsDiv);
      loadPaymentsForEvent(eventId, paymentsDiv.querySelector('.payments-inner'));
      el.dataset.paymentsAttached = '1';
    });
  });

  observer.observe(organizerEventsContainer, { childList: true, subtree: true });
});
