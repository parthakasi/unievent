// ========================= STUDENT DASHBOARD JS =========================
document.addEventListener("DOMContentLoaded", async () => {
  console.log("✅ Student Dashboard Loaded");

  // 🧩 Session check
  const studentId = sessionStorage.getItem("studentUserId");
  if (!studentId) {
    sessionStorage.clear();
    window.location.href = "student-login-form.html";
    return;
  }

  // ✅ Display header info
  const userName = sessionStorage.getItem("studentUserName") || "Student";
  const userYear = sessionStorage.getItem("studentUserYear") || "";
  const deptName = sessionStorage.getItem("studentDeptName") || "";
  const welcome = document.getElementById("welcome-message");
  if (welcome)
    welcome.textContent = `Hello, ${userName} (${userYear} Year - ${deptName})`;

  // ✅ Logout
  const logout = document.getElementById("logout-btn");
  if (logout) {
    logout.addEventListener("click", () => {
      sessionStorage.clear();
      showAlert("You have been logged out successfully!", "info");
      setTimeout(() => (window.location.href = "index.html"), 1000);
    });
  }

  // 🧭 Tabs Navigation
  const tabs = document.querySelectorAll(".tab-btn");
  const sections = {
    dashboard: document.getElementById("section-dashboard"),
    registrations: document.getElementById("section-registrations"),
    profile: document.getElementById("section-profile"),
  };

  function activateTab(tabId) {
    tabs.forEach((btn) => btn.classList.remove("active"));
    Object.values(sections).forEach((sec) => (sec.style.display = "none"));

    const currentTab = document.getElementById(`tab-${tabId}`);
    if (currentTab) currentTab.classList.add("active");
    if (sections[tabId]) sections[tabId].style.display = "block";

    if (tabId === "registrations") loadMyRegistrations();
    if (tabId === "profile") loadStudentProfile();
  }

  activateTab("dashboard");

  tabs.forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.id.replace("tab-", "");
      activateTab(id);
    });
  });

  // 🧭 Filters
  const dept = document.getElementById("dept-filter");
  const type = document.getElementById("type-filter");

  if (dept && type) {
    dept.addEventListener("change", () =>
      fetchAndRenderEvents(dept.value, type.value)
    );
    type.addEventListener("change", () =>
      fetchAndRenderEvents(dept.value, type.value)
    );
  }

  // Initial event load
  fetchAndRenderEvents("all", "all");
});

// ================== EVENT FETCH + RENDER ==================
const DEFAULT_IMAGE =
  "https://placehold.co/300x150/5c6bc0/ffffff?text=UniEvent";
let registeredCompIds = new Set();

const renderEventCard = (event) => {
  const imageUrl =
    event.photo_url && !event.photo_url.includes("placeholder_upload")
      ? event.photo_url
      : DEFAULT_IMAGE;

  const date = new Date(event.date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
  const time = `${event.start_time} - ${event.end_time}`;
  const isRegistered = event.competitions?.some((c) =>
    registeredCompIds.has(c.id)
  );
  const isClosed = event.registration_closed === 1;

  let badge = isClosed
    ? `<span class="registration-badge closed"><i class="fas fa-times-circle"></i> Closed</span>`
    : isRegistered
    ? `<span class="registration-badge registered"><i class="fas fa-check-circle"></i> Registered</span>`
    : `<span class="registration-badge not-registered">Open</span>`;

  return `
    <div class="event-card" data-event-id="${event.id}">
      <img src="${imageUrl}" alt="${event.title}" class="event-image">
      <div class="event-card-body">
        <div class="event-title-header">
          <h3 class="event-title">${event.title}</h3>
          ${badge}
        </div>
        <p class="event-meta">${event.department} | ${event.type}</p>
        <div class="event-details-row"><i class="fas fa-calendar"></i> ${date} • ${time}</div>
        <div class="event-details-row"><i class="fas fa-map-marker-alt"></i> ${event.venue}</div>
        <button class="btn primary-btn view-details-btn" data-event-id="${event.id}" ${
    isClosed ? "disabled" : ""
  }>
          ${isClosed ? "View Details" : "View Details & Register"}
        </button>
      </div>
    </div>`;
};

const fetchAndRenderEvents = async (department, type) => {
  const eventList = document.getElementById("event-list");
  eventList.innerHTML =
    '<p class="loading-message"><i class="fas fa-spinner fa-spin"></i> Loading events...</p>';

  const studentId = sessionStorage.getItem("studentUserId");
  if (!studentId) return;

  try {
    // 1️⃣ Registered competitions
    const res = await fetch(`/api/events/check-status/${studentId}`);
    if (res.ok) {
      const registered = await res.json();
      registeredCompIds = new Set(registered.map((r) => r.comp_id));
    }

    // 2️⃣ Fetch all events
    const resp = await fetch(
      `/api/events/all?department=${department}&type=${type}`
    );
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const events = await resp.json();

    // 3️⃣ Render
    if (!events || events.length === 0) {
      eventList.innerHTML =
        "<p class='empty-message'>No events found for the selected filters.</p>";
      return;
    }

    eventList.innerHTML = events.map(renderEventCard).join("");

    // 4️⃣ View Details Click
    document.querySelectorAll(".view-details-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.eventId;
        if (id) window.location.href = `event-details.html?eventId=${id}`;
      });
    });
  } catch (err) {
    console.error("Error fetching events:", err);
    eventList.innerHTML = `<p class="error-message">Could not load events. ${err.message}</p>`;
  }
};

// ================== MY REGISTRATIONS ==================
async function loadMyRegistrations() {
  const list = document.getElementById("my-registrations-list");
  const studentId = sessionStorage.getItem("studentUserId");
  if (!list || !studentId) return;

  list.innerHTML =
    "<p><i class='fas fa-spinner fa-spin'></i> Loading your registrations...</p>";

  try {
    const res = await fetch(`/api/users/my-registrations/${studentId}`);
    const data = await res.json();

    if (!res.ok || !data.length) {
      list.innerHTML = "<p>No registrations found.</p>";
      return;
    }

    list.innerHTML = data
      .map(
        (r) => `
        <div class="registration-card">
          <h4>${r.event_title}</h4>
          <p><strong>Competition:</strong> ${r.comp_name} (${r.comp_type})</p>
          <p><i class="fas fa-calendar"></i> ${new Date(
            r.event_date
          ).toDateString()}</p>
          <p><i class="fas fa-phone"></i> ${r.coordinator_phone}</p>
          <p><i class="fas fa-coins"></i> ₹${r.registration_fee || 0}</p>
          <p><i class="fas fa-clock"></i> Registered on ${new Date(
            r.registration_date
          ).toLocaleString()}</p>
        </div>`
      )
      .join("");
  } catch (e) {
    console.error("Error loading registrations:", e);
    list.innerHTML = "<p>Error loading your registrations.</p>";
  }
}

// ================== MY PROFILE (Editable) ==================
async function loadStudentProfile() {
  const studentId = sessionStorage.getItem("studentUserId");
  const container = document.getElementById("profile-container");
  if (!container || !studentId) return;

  container.innerHTML =
    "<p><i class='fas fa-spinner fa-spin'></i> Loading profile...</p>";

  try {
    const res = await fetch(`/api/users/profile/${studentId}`);
    const user = await res.json();

    if (!res.ok) {
      container.innerHTML = "<p>Failed to load profile.</p>";
      return;
    }

    container.innerHTML = `
  <div class="profile-card">
    <h2>Edit Profile</h2>
    <div class="profile-grid">
      <div>
        <label>Name</label>
        <input type="text" id="edit-name" value="${user.name || ""}" />
        <label>Register Number</label>
        <input type="text" id="edit-regno" value="${user.regno || ""}" />
        <label>Email</label>
        <input type="email" id="edit-email" value="${user.email || ""}" />
      </div>
      <div>
        <label>Phone</label>
        <input type="text" id="edit-phone" value="${user.phone || ""}" />
        <label>Department</label>
        <input type="text" id="edit-dept" value="${user.department || ""}" />
        <label>Year</label>
        <input type="text" id="edit-year" value="${user.year || ""}" />
      </div>
      <button class="btn primary-btn" id="save-profile-btn">
        <i class="fas fa-save"></i> Save Changes
      </button>
    </div>
  </div>
`;

    document
      .getElementById("save-profile-btn")
      .addEventListener("click", async () => {
        const updatedData = {
          userId: studentId,
          name: document.getElementById("edit-name").value,
          regno: document.getElementById("edit-regno").value,
          email: document.getElementById("edit-email").value,
          phone: document.getElementById("edit-phone").value,
          department: document.getElementById("edit-dept").value,
          year: document.getElementById("edit-year").value,
        };

        try {
          const res = await fetch(`/api/users/profile`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedData),
          });

          const result = await res.json();
          if (res.ok) {
            showAlert("Profile updated successfully!", "success");
            sessionStorage.setItem("studentUserName", updatedData.name);
            sessionStorage.setItem("studentDeptName", updatedData.department);
            sessionStorage.setItem("studentUserYear", updatedData.year);
          } else {
            showAlert(result.error || "Failed to update profile.", "error");
          }
        } catch (err) {
          console.error(err);
          showAlert("Error saving profile.", "error");
        }
      });
  } catch (err) {
    console.error("Profile fetch error:", err);
    container.innerHTML = "<p>Error loading profile.</p>";
  }
}
