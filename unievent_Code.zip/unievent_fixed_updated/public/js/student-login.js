document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  if (!loginForm) return;

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(loginForm);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await fetch('/api/users/login/student', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (response.ok) {
        showAlert(`Login successful! Welcome, ${result.name}!`, 'success');

        // ✅ Save session data consistently
        sessionStorage.setItem('userRole', 'student');   // important
        sessionStorage.setItem('studentUserId', result.userId);
        sessionStorage.setItem('studentUserName', result.name);
        sessionStorage.setItem('studentDeptName', result.department || '');
        sessionStorage.setItem('studentUserYear', result.year || '');

        // 🚫 Clear any organizer data
        sessionStorage.removeItem('organizerUserId');
        sessionStorage.removeItem('organizerUserName');
        sessionStorage.removeItem('organizerDeptName');

        // ✅ Redirect after short delay
        setTimeout(() => {
          window.location.href = 'student-dashboard.html';
        }, 1200);
      } else {
        showAlert(result.error || 'Invalid credentials. Please try again.', 'error');
      }
    } catch (error) {
      console.error('Login Error:', error);
      showAlert('A network error occurred. Please try again.', 'error');
    }
  });
});
