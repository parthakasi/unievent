
UniEvent - Upgrades applied (summary)
------------------------------------
Implemented features (partial, core backend + minimal frontend integration):
1. Organizer can upload QR image for a paid event via POST /api/payments/organizer/upload-qr (multipart form 'qr' + event_id).
2. Students can fetch QR via GET /api/payments/events/:id/qr and upload payment proof via POST /api/payments/events/:id/upload-proof (multipart 'proof' and user_id field).
3. Payments stored in new 'payments' table with status 'pending' (organizer can verify via POST /api/payments/payments/:id/verify).
4. Server serves uploaded files at /uploads.
5. Added simple client script to event-details.html (public/js/event-details-script.js) which displays QR and allows proof upload.
6. Added endpoint GET /api/events/check-registration to toggle 'Register' button state in frontend.
7. Kept other routes intact; created uploads/ directory for storing images.
8. package.json updated to include 'multer'.

How to run locally:
- npm install (this will install multer)
- npm run dev (or npm start)
- Visit http://localhost:3000/

How to deploy updated project to Render:
Option A - GitHub auto-deploy (recommended):
1. Commit changes to a branch and push to GitHub.
2. In Render dashboard, connect your GitHub repo (if not connected), or update the repository to the new commit/branch.
3. Render will auto-deploy; or trigger a manual deploy by clicking 'Manual Deploy' -> 'Deploy Latest Commit'.

Option B - Manual (zip upload / new service):
1. Create a new service on Render (Web Service) and select 'Deploy from a repo' or 'Manual' if available.
2. If uploading zip, ensure the start command is 'npm start' and build command empty.
3. Ensure the 'uploads' directory is writable; for persistent uploads, use Render's Persistent Disks or an external storage (S3) — Render ephemeral filesystem will not persist between deploys.

Notes & Next steps I didn't fully complete (I can do next if you want):
- Disable venues on event-creation UI when a timeslot is booked (requires checking events.js create route and front-end form).
- Mark registration entries with payment status and show 'Paid'/'Not Paid' on organizer dashboard (requires organizer dashboard UI changes and organizer side verification UI).
- Team registration flow: backend stub exists in registrations; full form UI to input team members not fully integrated.
- Additional validation, security, and UI polish.

