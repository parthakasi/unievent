const express = require('express');
const router = express.Router();
const db = require('../models/db'); 

// Global object to store temporary OTPs
const otpStore = {};
const generateOTP = () => Math.floor(1000 + Math.random() * 9000).toString();

// ==========================================================
// 1. STUDENT REGISTRATION
// ==========================================================
router.post('/register/student', (req, res) => {
  const { name, email, phone, regno, department, year, password, 'confirm-password': confirmPassword } = req.body;

  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  const stmt = db.prepare(`
    INSERT INTO users (name, email, phone, regno, department, year, password, role)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run(name, email, phone, regno, department, year, password, 'student', function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(409).json({ error: 'Email or Register Number already in use.' });
      }
      console.error('Database error:', err.message);
      return res.status(500).json({ error: 'A server error occurred during registration.' });
    }
    res.status(201).json({ message: 'Registration successful!' });
  });

  stmt.finalize();
});

// ==========================================================
// 2. ORGANIZER REGISTRATION
// ==========================================================
router.post('/register/organizer', (req, res) => {
  const { name, email, department, password, 'confirm-password': confirmPassword } = req.body;

  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  const stmt = db.prepare(`
    INSERT INTO users (name, email, department, password, role)
    VALUES (?, ?, ?, ?, 'organizer')
  `);

  stmt.run(name, email, department, password, function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(409).json({ error: 'Email already in use.' });
      }
      console.error('Database error:', err.message);
      return res.status(500).json({ error: 'A server error occurred during registration.' });
    }
    res.status(201).json({ message: 'Organizer registration successful!' });
  });

  stmt.finalize();
});

// ==========================================================
// 3. STUDENT LOGIN
// ==========================================================
router.post('/login/student', (req, res) => {
  const { identifier, password } = req.body;

  const query = 'SELECT id, name, password, year, department FROM users WHERE (regno = ? OR email = ?) AND role = ?';
  db.get(query, [identifier, identifier, 'student'], (err, user) => {
    if (err) return res.status(500).json({ error: 'Server error during login.' });
    if (!user) return res.status(401).json({ error: 'Invalid Register Number or Email.' });
    if (user.password !== password) return res.status(401).json({ error: 'Incorrect Password.' });

    res.json({
      message: 'Login successful',
      name: user.name,
      userId: user.id,
      year: user.year,
      department: user.department
    });
  });
});

// ==========================================================
// 4. ORGANIZER LOGIN
// ==========================================================
router.post('/login/organizer', (req, res) => {
  const { email, password } = req.body;

  const query = 'SELECT id, name, department, password FROM users WHERE email = ? AND role = ?';
  db.get(query, [email, 'organizer'], (err, user) => {
    if (err) return res.status(500).json({ error: 'Server error during login.' });
    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    res.json({
      message: 'Login successful',
      name: user.name,
      userId: user.id,
      department: user.department
    });
  });
});

// ==========================================================
// 5. GET STUDENT PROFILE
// ==========================================================
router.get('/profile/:userId', (req, res) => {
  const userId = req.params.userId;

  db.get('SELECT name, email, phone, regno, department, year FROM users WHERE id = ? AND role = "student"', [userId], (err, user) => {
    if (err) return res.status(500).json({ error: 'Failed to retrieve profile.' });
    if (!user) return res.status(404).json({ error: 'Profile not found.' });
    res.json(user);
  });
});

// ==========================================================
// 6. UPDATE PROFILE
// ==========================================================
router.put('/profile', (req, res) => {
  const { userId, name, regno, email, phone, department, year } = req.body;
  if (!userId) return res.status(400).json({ error: 'User ID required.' });

  const query = `
    UPDATE users
    SET name = ?, regno = ?, email = ?, phone = ?, department = ?, year = ?
    WHERE id = ? AND role = 'student'
  `;
  db.run(query, [name, regno, email, phone, department, year, userId], function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(409).json({ error: 'Email or Register Number already in use.' });
      }
      return res.status(500).json({ error: 'Failed to update profile.' });
    }
    if (this.changes === 0) return res.status(404).json({ error: 'Profile not found or unchanged.' });
    res.json({ message: 'Profile updated successfully!' });
  });
});

// ==========================================================
// 7. FORGOT PASSWORD FLOW (OTP + RESET)
// ==========================================================
router.post('/request-otp', (req, res) => {
  const { email, phone } = req.body;
  db.get('SELECT email, phone FROM users WHERE email = ? AND phone = ?', [email, phone], (err, user) => {
    if (err || !user) return res.status(400).json({ error: 'Invalid email/phone combination.' });

    const otp = generateOTP();
    otpStore[email] = { otp, timestamp: Date.now(), validUntil: Date.now() + 5 * 60 * 1000 };
    console.log(`OTP for ${email}: ${otp}`);
    res.json({ message: `OTP sent successfully to ${email}` });
  });
});

router.post('/verify-otp', (req, res) => {
  const { email, otp } = req.body;
  const data = otpStore[email];
  if (!data) return res.status(400).json({ error: 'OTP expired or invalid.' });
  if (data.timestamp < Date.now() - 5 * 60 * 1000) {
    delete otpStore[email];
    return res.status(400).json({ error: 'OTP expired.' });
  }
  if (data.otp === otp) {
    delete otpStore[email];
    res.json({ message: 'OTP verified successfully.' });
  } else {
    res.status(401).json({ error: 'Invalid OTP.' });
  }
});

router.post('/reset-password', (req, res) => {
  const { email, newPassword, confirmPassword } = req.body;
  if (newPassword !== confirmPassword) return res.status(400).json({ error: 'Passwords do not match.' });

  db.run('UPDATE users SET password = ? WHERE email = ?', [newPassword, email], function(err) {
    if (err) return res.status(500).json({ error: 'Failed to reset password.' });
    if (this.changes === 0) return res.status(404).json({ error: 'User not found.' });
    res.json({ message: 'Password reset successful.' });
  });
});

// ==========================================================
// 8. ⚠️ REMOVED DUPLICATE COMPETITION REGISTRATION ENDPOINT
//    (Now handled properly in routes/events.js)
// ==========================================================

// ==========================================================
// 9. FETCH MY REGISTRATIONS
// ==========================================================
router.get('/my-registrations/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = `
    SELECT 
      r.registration_date,
      e.title AS event_title,
      e.date AS event_date,
      c.comp_name,
      c.comp_type,
      c.coordinator_phone,
      c.registration_fee
    FROM registrations r
    JOIN competitions c ON r.comp_id = c.id
    JOIN events e ON r.event_id = e.id
    WHERE r.user_id = ?
    ORDER BY e.date ASC
  `;

  db.all(query, [userId], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to load registrations.' });
    res.json(rows);
  });
});

// ==========================================================
// 10. CHECK REGISTRATION STATUS
// ==========================================================
router.get('/check-status/:userId', (req, res) => {
  db.all('SELECT comp_id, event_id FROM registrations WHERE user_id = ?', [req.params.userId], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to check status.' });
    res.json(rows);
  });
});

module.exports = router;
