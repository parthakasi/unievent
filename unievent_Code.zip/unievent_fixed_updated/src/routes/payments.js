const express = require('express');
const router = express.Router();
const db = require('../models/db');
const multer = require('multer');
const path = require('path');
const uploadDir = path.join(__dirname, '..', '..', 'uploads');
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir)
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random()*1E9);
    cb(null, unique + '-' + file.originalname.replace(/\s+/g,'_'));
  }
});
const upload = multer({ storage: storage });

// Organizer uploads QR image for an event
router.post('/organizer/upload-qr', upload.single('qr'), (req, res) => {
  const { event_id, organizer_id } = req.body;
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const qr_path = '/uploads/' + req.file.filename;
  const sql = `UPDATE events SET qr_path = ? WHERE id = ?`;
  db.run(sql, [qr_path, event_id], function(err){
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ message: 'QR uploaded', qr_path });
  });
});

// Get QR for event
router.get('/events/:id/qr', (req, res) => {
  const id = req.params.id;
  db.get('SELECT qr_path FROM events WHERE id = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (!row || !row.qr_path) return res.status(404).json({ error: 'QR not found' });
    res.json({ qr_path: row.qr_path });
  });
});

// Student uploads payment proof
router.post('/events/:id/upload-proof', upload.single('proof'), (req, res) => {
  const eventId = req.params.id;
  const { user_id } = req.body;
  if (!req.file) return res.status(400).json({ error: 'No proof uploaded' });
  const proof_path = '/uploads/' + req.file.filename;
  const sql = `INSERT INTO payments(event_id, user_id, proof_path, status, uploaded_at) VALUES(?,?,?,?,datetime('now'))`;
  db.run(sql, [eventId, user_id, proof_path, 'pending'], function(err){
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ message: 'Proof uploaded', proof_path, payment_id: this.lastID });
  });
});

// Admin/Organizer mark payment as verified (paid)
router.post('/payments/:id/verify', (req, res) => {
  const paymentId = req.params.id;
  const { status } = req.body; // 'paid' or 'rejected'
  const sql = `UPDATE payments SET status = ? WHERE id = ?`;
  db.run(sql, [status, paymentId], function(err){
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ message: 'Payment updated' });
  });
});

module.exports = router;


// List payments for an event (organizer view)
router.get('/events/:id/payments', (req, res) => {
  const eventId = req.params.id;
  const sql = `SELECT p.id, p.user_id, p.proof_path, p.status, p.uploaded_at, u.name AS user_name
               FROM payments p LEFT JOIN users u ON u.id = p.user_id
               WHERE p.event_id = ? ORDER BY p.uploaded_at DESC`;
  db.all(sql, [eventId], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ payments: rows });
  });
});
