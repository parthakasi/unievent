// ========================== routes/events.js ==========================
const express = require("express");
const router = express.Router();
const db = require("../models/db");

// Utility: Time overlap check
const checkOverlap = (start_time, end_time, existing_start, existing_end) =>
  start_time < existing_end && end_time > existing_start;

// ==========================================================
// ✅ 1. FETCH ALL EVENTS WITH COMPETITIONS (Student Dashboard)
// ==========================================================
router.get("/all", (req, res) => {
  const { department, type } = req.query;
  let query = "SELECT * FROM events WHERE 1=1";
  const params = [];

  if (department && department !== "all") {
    query += " AND department = ?";
    params.push(department);
  }
  if (type && type !== "all") {
    query += " AND type = ?";
    params.push(type);
  }

  db.all(query, params, (err, events) => {
    if (err) {
      console.error("Filtered Event Fetch Error:", err.message);
      return res.status(500).json({ error: "Failed to fetch events." });
    }

    if (events.length === 0) return res.json([]);

    db.all("SELECT * FROM competitions", (err, comps) => {
      if (err) return res.status(500).json({ error: "Failed to fetch competitions." });

      const merged = events.map((e) => ({
        ...e,
        competitions: comps.filter((c) => c.event_id === e.id),
      }));
      res.json(merged);
    });
  });
});

// ==========================================================
// ✅ 2. GET SINGLE EVENT DETAILS
// ==========================================================
router.get("/:id", (req, res) => {
  const sql = `
    SELECT id, title, type, department, description, photo_url,
           date, venue, start_time, end_time, max_comps_per_student, organizer_id
    FROM events WHERE id = ?`;
  db.get(sql, [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: "Database error fetching event." });
    if (!row) return res.status(404).json({ error: "Event not found" });
    res.json({ event: row });
  });
});

// ==========================================================
// ✅ 3. VENUE CONFLICT CHECK
// ==========================================================
router.post("/check-conflict", (req, res) => {
  const { date, venue, start_time, end_time } = req.body;
  const sql = `SELECT start_time, end_time FROM events WHERE date = ? AND venue = ?`;
  db.all(sql, [date, venue], (err, rows) => {
    if (err) return res.status(500).json({ error: "Conflict check failed." });
    const conflict = rows.some((r) => checkOverlap(start_time, end_time, r.start_time, r.end_time));
    res.json({ isConflict: conflict });
  });
});

// ==========================================================
// ✅ 4. ADD NEW EVENT (Organizer)
// ==========================================================
router.post("/add", (req, res) => {
  const {
    title,
    type,
    department,
    description,
    photo_url,
    date,
    venue,
    start_time,
    end_time,
    max_comps_per_student,
    organizer_id,
    competitions,
  } = req.body;

  db.serialize(() => {
    db.run("BEGIN TRANSACTION");

    db.run(
      `INSERT INTO events (title, type, department, description, photo_url, date, venue, start_time, end_time, max_comps_per_student, organizer_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        title,
        type,
        department,
        description,
        photo_url,
        date,
        venue,
        start_time,
        end_time,
        max_comps_per_student,
        organizer_id,
      ],
      function (err) {
        if (err) {
          console.error("Event Insert Error:", err.message);
          return db.run("ROLLBACK", () => res.status(500).json({ error: "Event creation failed." }));
        }

        const eventId = this.lastID;
        if (!competitions || !competitions.length) {
          db.run("COMMIT");
          return res.status(201).json({ message: "Event added successfully!", eventId });
        }

        let success = true;
        competitions.forEach((c) => {
          db.run(
            `INSERT INTO competitions (event_id, comp_name, comp_description, comp_type, coordinator_phone, team_min, team_max, payment_required, registration_fee)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              eventId,
              c.comp_name,
              c.comp_description,
              c.comp_type,
              c.coordinator_phone,
              c.team_min,
              c.team_max,
              c.payment_required,
              c.registration_fee,
            ],
            (err) => {
              if (err) {
                success = false;
                console.error("Competition Insert Error:", err.message);
              }
            }
          );
        });

        if (success) db.run("COMMIT");
        res.status(201).json({ message: `Event "${title}" created successfully!`, eventId });
      }
    );
  });
});

// ==========================================================
// ✅ 5. ORGANIZER SUMMARY
// ==========================================================
router.get("/summary/:department", (req, res) => {
  const dept = req.params.department;
  db.get(
    "SELECT COUNT(*) AS totalEvents FROM events WHERE department = ?",
    [dept],
    (err, eventCount) => {
      if (err) return res.status(500).json({ error: "Event count fetch failed." });
      db.get(
        `SELECT COUNT(r.id) AS totalRegistrations
         FROM registrations r JOIN events e ON r.event_id = e.id WHERE e.department = ?`,
        [dept],
        (err, regCount) => {
          if (err) return res.status(500).json({ error: "Registration count failed." });
          res.json({
            totalActiveEvents: eventCount.totalEvents,
            eventsPendingApproval: 0,
            totalRegistrations: regCount.totalRegistrations,
          });
        }
      );
    }
  );
});

// ==========================================================
// ✅ 6. ORGANIZER’S EVENTS WITH STATS
// ==========================================================
router.get("/department/:department/:organizerId", (req, res) => {
  const orgId = req.params.organizerId;
  const sql = `
    SELECT e.id, e.title, e.date, e.start_time, e.end_time, e.venue, e.registration_closed,
           COUNT(DISTINCT c.id) AS totalComps, COUNT(r.id) AS totalRegistrations
    FROM events e
    LEFT JOIN competitions c ON e.id = c.event_id
    LEFT JOIN registrations r ON e.id = r.event_id
    WHERE e.organizer_id = ?
    GROUP BY e.id
    ORDER BY e.date DESC`;

  db.all(sql, [orgId], (err, rows) => {
    if (err) return res.status(500).json({ error: "Failed to fetch organizer events." });
    res.json(rows);
  });
});

// ==========================================================
// ✅ 7. FETCH REGISTRATIONS FOR ONE EVENT (Organizer View)
// ==========================================================
router.get("/registrations/:eventId", (req, res) => {
  const sql = `
    SELECT r.registration_date, u.name AS student_name, u.regno, u.department AS student_dept,
           u.phone, c.comp_name, c.comp_type, c.registration_fee
    FROM registrations r
    JOIN users u ON r.user_id = u.id
    JOIN competitions c ON r.comp_id = c.id
    WHERE r.event_id = ?
    ORDER BY c.comp_name, u.name`;
  db.all(sql, [req.params.eventId], (err, rows) => {
    if (err) return res.status(500).json({ error: "Failed to fetch registration details." });
    res.json(rows);
  });
});

// ==========================================================
// ✅ 8. STUDENT COMPETITION REGISTRATION
// ==========================================================
router.post("/register", (req, res) => {
  const { event_id, comp_id, user_id, team_members } = req.body;
  if (!user_id) return res.status(401).json({ error: "Login required." });

  db.get("SELECT registration_closed FROM events WHERE id = ?", [event_id], (err, e) => {
    if (err || !e) return res.status(500).json({ error: "Event lookup failed." });
    if (e.registration_closed === 1) return res.status(403).json({ error: "Registration closed." });

    const insertReg = (uid, cb) => {
      db.run(
        `INSERT INTO registrations(event_id, comp_id, user_id, registration_date)
         VALUES(?,?,?, datetime('now'))`,
        [event_id, comp_id, uid],
        function (err) {
          cb(err, this.lastID);
        }
      );
    };

    db.get(
      "SELECT id FROM registrations WHERE event_id=? AND comp_id=? AND user_id=?",
      [event_id, comp_id, user_id],
      (err, existing) => {
        if (existing) return res.status(409).json({ error: "Already registered." });

        if (Array.isArray(team_members) && team_members.length) {
          insertReg(user_id, (err) => {
            if (err) return res.status(500).json({ error: "Primary registration failed." });
            const next = (i) => {
              if (i >= team_members.length) return res.json({ message: "Team registered successfully!" });
              const m = team_members[i];
              if (!m.email) return next(i + 1);
              db.get("SELECT id FROM users WHERE email = ?", [m.email], (err, row) => {
                if (row) {
                  insertReg(row.id, (e) => (e ? res.status(500).json({ error: "Member registration failed." }) : next(i + 1)));
                } else {
                  db.run(
                    "INSERT INTO users(name, email, department, role) VALUES(?,?,?,'student')",
                    [m.name || m.email, m.email, m.department || ""],
                    function (err) {
                      if (err) return res.status(500).json({ error: "User insert failed." });
                      insertReg(this.lastID, (e) =>
                        e ? res.status(500).json({ error: "Member registration failed." }) : next(i + 1)
                      );
                    }
                  );
                }
              });
            };
            next(0);
          });
        } else {
          insertReg(user_id, (err) => {
            if (err) return res.status(500).json({ error: "Registration failed." });
            res.json({ message: "Registered successfully!" });
          });
        }
      }
    );
  });
});

// ==========================================================
// ✅ 9. STUDENT REGISTRATION STATUS CHECK
// ==========================================================
router.get("/check-status/:userId", (req, res) => {
  db.all("SELECT comp_id FROM registrations WHERE user_id = ?", [req.params.userId], (err, rows) => {
    if (err) return res.status(500).json({ error: "Status check failed." });
    res.json(rows);
  });
});

// ==========================================================
// ✅ 10. MY REGISTRATIONS (Student Dashboard Tab)
// ==========================================================
router.get("/my-registrations/:userId", (req, res) => {
  const sql = `
    SELECT r.registration_date, e.title AS event_title, e.date AS event_date,
           c.comp_name, c.comp_type, c.coordinator_phone, c.registration_fee
    FROM registrations r
    JOIN competitions c ON r.comp_id = c.id
    JOIN events e ON r.event_id = e.id
    WHERE r.user_id = ?
    ORDER BY e.date ASC`;
  db.all(sql, [req.params.userId], (err, rows) => {
    if (err) return res.status(500).json({ error: "Failed to fetch student registrations." });
    res.json(rows);
  });
});

// ==========================================================
// ✅ 11. CLOSE REGISTRATION
// ==========================================================
router.post("/close/:eventId", (req, res) => {
  db.run(`UPDATE events SET registration_closed = 1 WHERE id = ?`, [req.params.eventId], function (err) {
    if (err) return res.status(500).json({ error: "Failed to close registration." });
    res.json({ message: "Event registration closed successfully." });
  });
});

// ==========================================================
// ✅ 12. DELETE EVENT
// ==========================================================
router.delete("/delete/:eventId", (req, res) => {
  db.serialize(() => {
    db.run("BEGIN TRANSACTION");
    db.run("DELETE FROM registrations WHERE event_id = ?", [req.params.eventId]);
    db.run("DELETE FROM competitions WHERE event_id = ?", [req.params.eventId]);
    db.run("DELETE FROM events WHERE id = ?", [req.params.eventId], function (err) {
      if (err) {
        db.run("ROLLBACK");
        return res.status(500).json({ error: "Failed to delete event." });
      }
      db.run("COMMIT");
      res.json({ message: "Event deleted permanently." });
    });
  });
});

module.exports = router;
